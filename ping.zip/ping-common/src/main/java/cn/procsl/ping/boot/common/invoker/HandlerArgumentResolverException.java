package cn.procsl.ping.boot.common.invoker;

public class HandlerArgumentResolverException extends RuntimeException {
}
