package cn.procsl.ping.boot.common.event;

public class EventPublishException extends RuntimeException {

    public EventPublishException(String message) {
        super(message);
    }
}
