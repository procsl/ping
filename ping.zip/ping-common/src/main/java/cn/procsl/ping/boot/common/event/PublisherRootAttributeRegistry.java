package cn.procsl.ping.boot.common.event;

import java.util.Map;

public interface PublisherRootAttributeRegistry {

    Map<String, Object> getAttributes();

}
