package cn.procsl.ping.boot.common.service;

public interface PasswordEncoderService {

    String encode(CharSequence password);

}
