package cn.procsl.ping.boot.common.invoker;

public interface HandlerInvokerExceptionResolver {

    void resolve(Exception e);

}
