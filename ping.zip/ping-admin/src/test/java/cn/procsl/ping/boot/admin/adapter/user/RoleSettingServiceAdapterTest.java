package cn.procsl.ping.boot.admin.adapter.user;

import org.junit.jupiter.api.Test;

class RoleSettingServiceAdapterTest {

    @Test
    void grant() {
    }

    @Test
    void getDefaultRoles() {
    }

    @Test
    void defaultRoleSetting() {
    }
}