package cn.procsl.ping.boot.admin.domain.user;

public enum AccountState {

    disable, enable

}
