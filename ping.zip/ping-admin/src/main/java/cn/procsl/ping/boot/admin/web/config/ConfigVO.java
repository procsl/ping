package cn.procsl.ping.boot.admin.web.config;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConfigVO extends ConfigDTO {

    Long id;

}
