package cn.procsl.ping.boot.admin.advice;

import java.util.Map;

public interface DataPermissionRootAttributeRegistry {

    Map<String, Object> getAttributes();

}
