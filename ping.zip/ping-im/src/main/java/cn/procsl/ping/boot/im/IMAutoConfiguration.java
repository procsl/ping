package cn.procsl.ping.boot.im;

import org.springframework.boot.autoconfigure.AutoConfiguration;

@AutoConfiguration
public class IMAutoConfiguration {
}
